# Changelog

Alle nennenswerten Änderungen dieses Projekts werden in diesem Dokument festgehalten.

## [1.0.0] - 2025-08-19
- Erste veröffentlichte Version.
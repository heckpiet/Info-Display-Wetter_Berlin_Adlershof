# Verhaltenskodex

Wir erwarten respektvolle, inklusive Zusammenarbeit. Keine Diskriminierung, kein Trolling.
Verstöße bitte an **maintainer@example.org** melden.
# Sicherheitsrichtlinie

## Unterstützte Versionen
Wir pflegen nur die **aktuellste** veröffentlichte Version (letzter Git-Tag).

## Sicherheitslücken melden
Bitte sende Hinweise verantwortungsvoll per E‑Mail an **security@example.org**.
Füge wenn möglich eine reproduzierbare Beschreibung, Logs und Screenshots bei.
Wir bestätigen den Eingang innerhalb von 3 Werktagen.